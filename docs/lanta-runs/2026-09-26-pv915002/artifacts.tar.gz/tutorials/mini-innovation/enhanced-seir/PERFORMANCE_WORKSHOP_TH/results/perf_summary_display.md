# Performance Summary Display

- figures/perf_summary_speedup.svg
- figures/perf_summary_efficiency.svg
- figures/perf_summary_overhead.svg
- figures/perf_summary_python_stack.svg
