# Performance Workshop Report

source=results/solver_roofline_6339673.csv

| ranks | elapsed | speedup | efficiency | overhead | serial_fraction | wall |
|---:|---:|---:|---:|---:|---:|---|
| 1 | 0.907805 | 1.000 | 1.000 | 0.000000 | 0.0000 | memory bandwidth |
| 2 | 0.452350 | 2.007 | 1.003 | -0.001553 | 0.0000 | memory bandwidth |
| 4 | 0.243285 | 3.731 | 0.933 | 0.016334 | 0.0240 | memory bandwidth |

## Interpretation

- Low arithmetic intensity points to memory traffic as the first roofline signal.
- Efficiency drop across ranks marks synchronization, halo exchange, and Allreduce overhead.
- SEIR compare found: results/seir_perf_compare.csv; engines=C++/MPI,PyTorch/GPU.
