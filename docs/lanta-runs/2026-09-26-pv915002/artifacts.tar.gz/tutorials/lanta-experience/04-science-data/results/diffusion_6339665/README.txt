question: 1D diffusion baseline
workspace: /lustrefs/disk/project/pv915002-hpcign/wdiazcar/hpc-ignite-rerun-20260926/tutorials/lanta-experience/04-science-data
date: 2026-09-26T08:13:23+07:00
job: 6339665
result: results/diffusion_6339665.csv
validation: CSV has header i,value and N rows
